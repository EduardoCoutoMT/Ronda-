package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PmmtGold
import com.example.ui.theme.PmmtNavy
import com.example.ui.theme.PmmtNavyDark

data class ExportedDocument(
  val filename: String,
  val content: String,
  val mimeType: String,
)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(PmmtNavyDark.toArgb()),
      navigationBarStyle = SystemBarStyle.dark(PmmtNavyDark.toArgb()),
    )
    setContent {
      MyApplicationTheme {
        RondaMtHybridApp(onExitApp = { finish() })
      }
    }
  }
}

private const val CORDOVA_BRIDGE_JS = """
(function() {
  if (window.__rondaBridgeInstalled) return;
  window.__rondaBridgeInstalled = true;

  window.DL = {
    save: function(payload) {
      if (window.AndroidBridge && payload) {
        var name = String(payload.filename || 'ronda-mt-export.txt');
        var data = String(payload.data || '');
        window.AndroidBridge.onExportFile(name, data);
      }
    }
  };

  window.print = function() {
    if (window.AndroidBridge) {
      window.AndroidBridge.onPrintPage();
    }
  };

  if (navigator) {
    navigator.vibrate = function(pattern) {
      if (window.AndroidBridge) {
        var serialized = Array.isArray(pattern) ? pattern.join(',') : String(pattern || 250);
        window.AndroidBridge.onVibrate(serialized);
        return true;
      }
      return false;
    };
  }

  window.__rondaHandleBack = function() {
    try {
      var alarmEl = document.getElementById('alarm');
      if (alarmEl && alarmEl.classList.contains('open')) {
        if (typeof closeAlarm === 'function') closeAlarm();
        return 'HANDLED';
      }
      var modalEl = document.getElementById('modal');
      if (modalEl && modalEl.classList.contains('open')) {
        if (typeof closeModal === 'function') closeModal();
        return 'HANDLED';
      }
      if (typeof S !== 'undefined' && S && S.ui) {
        if (S.ui.view === 'livro' && S.ui.ldSel) {
          S.ui.ldSel = null;
          if (typeof render === 'function') render();
          return 'HANDLED';
        }
        if (S.ui.view === 'livro' && S.ui.ldDia) {
          S.ui.ldDia = null;
          if (typeof render === 'function') render();
          return 'HANDLED';
        }
        if (S.ui.view === 'escalas' && S.ui.escSel) {
          S.ui.escSel = null;
          if (typeof render === 'function') render();
          return 'HANDLED';
        }
        if (S.ui.view && S.ui.view !== 'home') {
          if (typeof go === 'function') go('home');
          return 'HANDLED';
        }
      }
    } catch (e) {}
    return 'ROOT';
  };
})();
"""

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RondaMtHybridApp(onExitApp: () -> Unit) {
  val context = LocalContext.current
  var webViewRef by remember { mutableStateOf<WebView?>(null) }
  var pendingExport by remember { mutableStateOf<ExportedDocument?>(null) }
  var fileUploadCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

  // Zero-permission Android Photo Picker for image attachments (Abordagem, Abastecimento, Checklist)
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    val callback = fileUploadCallback
    fileUploadCallback = null
    if (uri != null) {
      callback?.onReceiveValue(arrayOf(uri))
    } else {
      callback?.onReceiveValue(null)
    }
  }

  // Document picker for JSON backup restoration
  val documentPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    val callback = fileUploadCallback
    fileUploadCallback = null
    if (uri != null) {
      callback?.onReceiveValue(arrayOf(uri))
    } else {
      callback?.onReceiveValue(null)
    }
  }

  // Document creator for saving exported .html, .csv, or .json files to user-selected location
  val createDocumentLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("*/*")
  ) { uri: Uri? ->
    val doc = pendingExport
    if (uri != null && doc != null) {
      runCatching {
        context.contentResolver.openOutputStream(uri)?.use { out ->
          out.write(doc.content.toByteArray(Charsets.UTF_8))
        }
        Toast.makeText(
          context,
          context.getString(R.string.file_saved_message, doc.filename),
          Toast.LENGTH_SHORT
        ).show()
      }
      pendingExport = null
    }
  }

  // Intercept Android system Back button and delegate to RONDA-MT internal navigation first
  BackHandler(enabled = true) {
    val wv = webViewRef
    if (wv == null) {
      onExitApp()
    } else {
      wv.evaluateJavascript("window.__rondaHandleBack && window.__rondaHandleBack();") { result ->
        val clean = result?.trim('"') ?: "ROOT"
        if (clean != "HANDLED") {
          if (wv.canGoBack()) {
            wv.goBack()
          } else {
            onExitApp()
          }
        }
      }
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(PmmtNavyDark)
      .testTag("ronda_mt_scaffold"),
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    containerColor = PmmtNavyDark,
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .statusBarsPadding()
        .navigationBarsPadding()
        .imePadding()
        .background(PmmtNavyDark)
    ) {
      AndroidView(
        modifier = Modifier
          .fillMaxSize()
          .testTag("ronda_mt_webview"),
        factory = { ctx ->
          WebView(ctx).apply {
            settings.apply {
              javaScriptEnabled = true
              domStorageEnabled = true
              databaseEnabled = true
              allowFileAccess = true
              allowContentAccess = true
              loadsImagesAutomatically = true
              mediaPlaybackRequiresUserGesture = false
              mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
              useWideViewPort = true
              loadWithOverviewMode = true
              setSupportZoom(false)
              builtInZoomControls = false
              displayZoomControls = false
              textZoom = 100
            }

            addJavascriptInterface(
              object {
                @JavascriptInterface
                fun onExportFile(filename: String, data: String) {
                  val safeName = filename.ifBlank { "ronda-mt-export.txt" }
                  val mime = when {
                    safeName.endsWith(".html", ignoreCase = true) -> "text/html"
                    safeName.endsWith(".csv", ignoreCase = true) -> "text/csv"
                    safeName.endsWith(".json", ignoreCase = true) -> "application/json"
                    else -> "text/plain"
                  }
                  post {
                    pendingExport = ExportedDocument(
                      filename = safeName,
                      content = data,
                      mimeType = mime,
                    )
                  }
                }

                @JavascriptInterface
                fun onPrintPage() {
                  post {
                    triggerWebViewPrint(ctx, this@apply, "RONDA-MT-Documento")
                  }
                }

                @JavascriptInterface
                fun onVibrate(patternCsv: String) {
                  triggerDeviceVibration(ctx, patternCsv)
                }
              },
              "AndroidBridge"
            )

            webViewClient = object : WebViewClient() {
              override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(CORDOVA_BRIDGE_JS, null)
              }

              override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
              ): Boolean {
                val targetUri = request?.url ?: return false
                return if (targetUri.scheme == "file" || targetUri.scheme == "about" || targetUri.scheme == "data" || targetUri.scheme == "blob") {
                  false
                } else {
                  runCatching {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, targetUri))
                  }
                  true
                }
              }
            }

            webChromeClient = object : WebChromeClient() {
              override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
              ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val accepts = fileChooserParams?.acceptTypes?.joinToString(",")?.lowercase().orEmpty()
                val wantsImage = accepts.contains("image")
                if (wantsImage) {
                  photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                } else {
                  documentPickerLauncher.launch(
                    arrayOf("application/json", "text/plain", "*/*")
                  )
                }
                return true
              }
            }

            loadUrl("file:///android_asset/ronda_mt.html")
            webViewRef = this
          }
        },
        update = { view ->
          webViewRef = view
        }
      )
    }

    // Native Export / Share / Print Modal Bottom Sheet when RONDA-MT triggers a file download
    val currentDoc = pendingExport
    if (currentDoc != null) {
      val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ModalBottomSheet(
        onDismissRequest = { pendingExport = null },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("export_document_sheet")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
          Text(
            text = "Exportação Nativa RONDA-MT",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = currentDoc.filename,
            style = MaterialTheme.typography.bodyMedium.copy(
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.SemiBold,
              color = PmmtGold
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(12.dp))

          Surface(
            color = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = currentDoc.content.take(420) + if (currentDoc.content.length > 420) "\n…" else "",
              style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                lineHeight = 15.sp
              ),
              modifier = Modifier.padding(12.dp),
              maxLines = 7,
              overflow = TextOverflow.Ellipsis
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = {
              createDocumentLauncher.launch(currentDoc.filename)
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = PmmtNavy,
              contentColor = Color.White
            ),
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("save_to_device_button")
          ) {
            Icon(Icons.Default.Download, contentDescription = "Salvar no dispositivo")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Salvar Arquivo no Dispositivo", fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_SUBJECT, currentDoc.filename)
                  putExtra(Intent.EXTRA_TEXT, currentDoc.content)
                }
                context.startActivity(
                  Intent.createChooser(
                    shareIntent,
                    context.getString(R.string.share_document_title)
                  )
                )
                pendingExport = null
              },
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("share_document_button")
            ) {
              Icon(Icons.Default.Share, contentDescription = "Compartilhar")
              Spacer(modifier = Modifier.width(6.dp))
              Text("Compartilhar")
            }

            if (currentDoc.filename.endsWith(".html", ignoreCase = true)) {
              OutlinedButton(
                onClick = {
                  printHtmlContent(context, currentDoc.filename, currentDoc.content)
                  pendingExport = null
                },
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("print_pdf_button")
              ) {
                Icon(Icons.Default.Print, contentDescription = "Gerar PDF / Imprimir")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Gerar PDF")
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))
        }
      }
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      webViewRef?.destroy()
      webViewRef = null
    }
  }
}

private fun triggerWebViewPrint(context: Context, webView: WebView, jobTitle: String) {
  runCatching {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
    val adapter = webView.createPrintDocumentAdapter(jobTitle)
    printManager.print(jobTitle, adapter, PrintAttributes.Builder().build())
  }
}

private fun printHtmlContent(context: Context, filename: String, htmlContent: String) {
  runCatching {
    val printWebView = WebView(context)
    printWebView.webViewClient = object : WebViewClient() {
      override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        if (view != null) {
          triggerWebViewPrint(context, view, filename.removeSuffix(".html"))
        }
      }
    }
    printWebView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
  }
}

private fun triggerDeviceVibration(context: Context, patternCsv: String) {
  runCatching {
    val timings = patternCsv
      .split(",")
      .mapNotNull { it.trim().toLongOrNull() }
      .filter { it > 0L }
    val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
      vm?.defaultVibrator
    } else {
      @Suppress("DEPRECATION")
      context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
    if (vibrator == null || !vibrator.hasVibrator()) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      if (timings.size > 1) {
        val wave = LongArray(timings.size + 1)
        wave[0] = 0L
        timings.forEachIndexed { idx, ms -> wave[idx + 1] = ms }
        vibrator.vibrate(VibrationEffect.createWaveform(wave, -1))
      } else {
        val duration = timings.firstOrNull() ?: 250L
        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
      }
    } else {
      @Suppress("DEPRECATION")
      vibrator.vibrate(timings.firstOrNull() ?: 250L)
    }
  }
}
