package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PmmtNavy = Color(0xFF13294B)
val PmmtNavyDark = Color(0xFF0D1F3B)
val PmmtNavyLight = Color(0xFF1E3D6B)
val PmmtGold = Color(0xFFC9961A)
val PmmtGoldBright = Color(0xFFE2B13C)
val PmmtBgLight = Color(0xFFF3F5F9)
val PmmtBgDark = Color(0xFF0B1320)
val PmmtCardDark = Color(0xFF131F33)
