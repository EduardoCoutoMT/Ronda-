package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = PmmtGoldBright,
  onPrimary = PmmtNavyDark,
  primaryContainer = PmmtNavy,
  onPrimaryContainer = Color.White,
  secondary = PmmtGold,
  onSecondary = PmmtNavyDark,
  background = PmmtBgDark,
  onBackground = Color(0xFFE6ECF5),
  surface = PmmtCardDark,
  onSurface = Color(0xFFE6ECF5),
)

private val LightColorScheme = lightColorScheme(
  primary = PmmtNavy,
  onPrimary = Color.White,
  primaryContainer = PmmtNavyLight,
  onPrimaryContainer = Color.White,
  secondary = PmmtGold,
  onSecondary = Color.White,
  background = PmmtBgLight,
  onBackground = Color(0xFF0F1B2D),
  surface = Color.White,
  onSurface = Color(0xFF0F1B2D),
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
